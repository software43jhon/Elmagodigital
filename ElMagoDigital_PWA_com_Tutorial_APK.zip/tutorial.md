# Tutorial de Hospedagem e Administração do ElMagoDigital

Este tutorial irá guiá-lo através do processo de hospedagem gratuita e administração do seu aplicativo ElMagoDigital com design futurista.

## Índice

1. [Visão Geral do Aplicativo](#visão-geral-do-aplicativo)
2. [Hospedagem Gratuita](#hospedagem-gratuita)
   - [Opção 1: Netlify](#opção-1-netlify)
   - [Opção 2: Vercel](#opção-2-vercel)
   - [Opção 3: GitHub Pages](#opção-3-github-pages)
3. [Acessando o Painel de Administração](#acessando-o-painel-de-administração)
4. [Gerenciando Cursos](#gerenciando-cursos)
5. [Personalizando o Aplicativo](#personalizando-o-aplicativo)
6. [Manutenção e Atualizações](#manutenção-e-atualizações)

## Visão Geral do Aplicativo

O ElMagoDigital é uma Progressive Web App (PWA) com design futurista para gerenciamento de cursos online. O aplicativo possui:

- Interface moderna com design futurista e efeitos neon
- Carrosséis de cursos e categorias
- Reprodutor de vídeo personalizado
- Sistema de login e registro
- Painel de administração para gerenciar cursos
- Suporte para modo offline
- Instalação como aplicativo nativo em dispositivos móveis e desktop

## Hospedagem Gratuita

Existem várias opções gratuitas para hospedar seu aplicativo ElMagoDigital. Vamos explorar as três mais populares e fáceis de usar.

### Opção 1: Netlify

O Netlify oferece hospedagem gratuita com recursos avançados como HTTPS, CDN global e implantação contínua.

#### Passo a passo:

1. Crie uma conta em [netlify.com](https://www.netlify.com/)
2. Após fazer login, clique em "New site from Git" ou arraste e solte a pasta do seu aplicativo na área indicada
3. Se optar por upload direto:
   - Compacte a pasta `app/src/main` em um arquivo ZIP
   - Arraste e solte o arquivo ZIP na área de upload do Netlify
   - O Netlify irá descompactar e publicar automaticamente

4. Após o upload, seu site estará disponível em um domínio aleatório como `random-name-123456.netlify.app`
5. Para personalizar o domínio:
   - Vá para "Site settings" > "Domain management"
   - Clique em "Custom domains" > "Add custom domain"
   - Você pode usar um subdomínio gratuito do Netlify ou conectar seu próprio domínio

### Opção 2: Vercel

O Vercel é outra excelente opção para hospedagem gratuita, especialmente para aplicativos web modernos.

#### Passo a passo:

1. Crie uma conta em [vercel.com](https://vercel.com/)
2. Após fazer login, clique em "New Project"
3. Você pode importar de um repositório Git ou fazer upload direto:
   - Para upload direto, clique em "Upload" na seção "Import Git Repository"
   - Selecione a pasta `app/src/main` do seu aplicativo
   - Clique em "Deploy"

4. Após a implantação, seu site estará disponível em um domínio como `project-name.vercel.app`
5. Para personalizar o domínio:
   - Vá para as configurações do projeto
   - Clique em "Domains"
   - Adicione seu domínio personalizado ou use o subdomínio gratuito fornecido

### Opção 3: GitHub Pages

O GitHub Pages é uma opção gratuita para hospedar sites diretamente de um repositório GitHub.

#### Passo a passo:

1. Crie uma conta no [github.com](https://github.com/) se ainda não tiver
2. Crie um novo repositório com o nome `elmagodigital`
3. Faça upload dos arquivos da pasta `app/src/main` para o repositório
4. Vá para "Settings" > "Pages"
5. Em "Source", selecione "main" e a pasta raiz (ou `/docs` se você moveu os arquivos para uma pasta docs)
6. Clique em "Save"
7. Seu site estará disponível em `seuusername.github.io/elmagodigital`

## Acessando o Painel de Administração

O ElMagoDigital possui um painel de administração integrado para gerenciar cursos e usuários.

### Como acessar:

1. Abra o aplicativo em seu navegador
2. Clique no botão "Entrar" no canto superior direito
3. Use as seguintes credenciais de administrador:
   - Email: `admin@elmagodigital.com`
   - Senha: `admin`
4. Após o login bem-sucedido, você será redirecionado automaticamente para o painel de administração

### Recursos do painel de administração:

- Dashboard com estatísticas gerais
- Gerenciamento de cursos (adicionar, editar, excluir)
- Visualização de alunos inscritos
- Métricas de desempenho

## Gerenciando Cursos

O painel de administração permite gerenciar facilmente os cursos disponíveis no aplicativo.

### Adicionar um novo curso:

1. Acesse o painel de administração
2. Clique no botão "Adicionar Curso"
3. Preencha o formulário com as informações do curso:
   - Título do curso
   - Descrição
   - Categoria
   - Imagem do curso (opcional)
4. Clique em "Adicionar Curso" para salvar

### Editar um curso existente:

1. Na lista de cursos, localize o curso que deseja editar
2. Clique no ícone de edição (✏️)
3. Faça as alterações necessárias
4. Clique em "Salvar Alterações"

### Excluir um curso:

1. Na lista de cursos, localize o curso que deseja excluir
2. Clique no ícone de exclusão (🗑️)
3. Confirme a exclusão quando solicitado

## Personalizando o Aplicativo

Você pode personalizar vários aspectos do aplicativo ElMagoDigital para atender às suas necessidades específicas.

### Alterando cores e tema:

1. Abra o arquivo `css/styles.css`
2. Localize a seção `:root` no início do arquivo
3. Modifique as variáveis de cores conforme desejado:
   ```css
   :root {
     --primary-background: #0B0E2D;
     --secondary-background: #1A1F4B;
     --primary-accent: #00E5FF;
     --secondary-accent: #FF00E5;
     /* outras variáveis */
   }
   ```

### Alterando o logotipo:

1. Substitua os arquivos em `images/icon-192x192.png` e `images/icon-512x512.png` por suas próprias imagens
2. Mantenha os mesmos nomes de arquivo e dimensões para compatibilidade

### Personalizando textos:

1. Abra o arquivo `index.html`
2. Localize e modifique os textos conforme necessário
3. Para textos dinâmicos, você precisará editar o arquivo `js/app.js`

## Manutenção e Atualizações

Para garantir que seu aplicativo ElMagoDigital continue funcionando corretamente, siga estas práticas recomendadas:

### Atualizações regulares:

1. Faça backup dos arquivos antes de qualquer atualização
2. Atualize regularmente as bibliotecas externas (como particles.js)
3. Teste todas as funcionalidades após as atualizações

### Solução de problemas comuns:

- **Problema**: O aplicativo não está instalando como PWA
  - **Solução**: Verifique se o manifest.json está configurado corretamente e se o service-worker.js está registrado

- **Problema**: Imagens não estão carregando
  - **Solução**: Verifique os caminhos das imagens e certifique-se de que os arquivos existem

- **Problema**: Não é possível acessar o painel de administração
  - **Solução**: Verifique as credenciais de login e certifique-se de que o JavaScript está habilitado no navegador

### Backup de dados:

Como este é um aplicativo front-end, os dados são armazenados localmente. Para implementar um sistema de backup:

1. Considere adicionar uma API backend para armazenamento persistente
2. Ou use serviços como Firebase para armazenamento em nuvem
3. Implemente exportação/importação de dados no painel de administração

---

Parabéns! Agora você tem um aplicativo ElMagoDigital com design futurista hospedado gratuitamente e sabe como administrá-lo. Se tiver dúvidas adicionais, não hesite em entrar em contato.
