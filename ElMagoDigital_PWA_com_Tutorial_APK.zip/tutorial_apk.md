# Tutorial Detalhado: Como Converter a PWA ElMagoDigital em APK

Este tutorial irá guiá-lo passo a passo no processo de converter a Progressive Web App (PWA) ElMagoDigital em um arquivo APK que pode ser instalado em qualquer dispositivo Android.

## Passo 1: Hospedar a PWA no Netlify

Primeiro, precisamos hospedar a PWA em um servidor web para que o PWA Builder possa acessá-la.

1. Acesse [netlify.com](https://www.netlify.com/) e crie uma conta gratuita (pode usar sua conta Google ou GitHub para agilizar)

2. Após fazer login, você verá o dashboard do Netlify. Clique no botão "Add new site" e selecione "Deploy manually"
   
3. Descompacte o arquivo ZIP "ElMagoDigital_PWA.zip" que você recebeu

4. Localize a pasta "app/src/main" dentro dos arquivos descompactados

5. Arraste e solte toda a pasta "main" na área de upload do Netlify (ou selecione os arquivos dentro dela)

6. Aguarde alguns segundos enquanto o Netlify processa e publica seu site

7. Quando concluído, o Netlify fornecerá uma URL aleatória para seu site (algo como "random-name-123456.netlify.app")

8. Clique na URL para verificar se o site está funcionando corretamente

## Passo 2: Converter em APK usando o PWA Builder

Agora que a PWA está hospedada, vamos convertê-la em um APK:

1. Acesse [pwabuilder.com](https://www.pwabuilder.com/)

2. Na página inicial, cole a URL do seu site Netlify no campo de texto

3. Clique no botão "Start" para iniciar a análise da PWA

4. O PWA Builder analisará seu site e mostrará uma pontuação. Não se preocupe se não for 100% - o importante é que seja possível gerar o APK

5. Clique no botão "Build" no canto superior direito

6. Na tela de opções de plataforma, selecione "Android"

7. Você verá opções de personalização. Para uma configuração básica, mantenha as opções padrão

8. Clique no botão "Download" para baixar o arquivo APK

9. O download começará automaticamente. O arquivo terá um nome como "pwabuilder-sw.apk" ou similar

## Passo 3: Instalar o APK no dispositivo Android

Agora que você tem o arquivo APK, vamos instalá-lo em um dispositivo Android:

1. Transfira o arquivo APK para seu dispositivo Android (usando email, WhatsApp, cabo USB, etc.)

2. No dispositivo Android, localize o arquivo APK e toque nele para iniciar a instalação

3. Se for a primeira vez que você instala um APK fora da Play Store, o Android solicitará permissão para instalar aplicativos de fontes desconhecidas:
   - Vá para Configurações > Segurança
   - Ative a opção "Fontes desconhecidas" ou "Instalar aplicativos desconhecidos"
   - Em versões mais recentes do Android, a permissão será solicitada por aplicativo

4. Confirme a instalação quando solicitado

5. Após a instalação, você encontrará o aplicativo ElMagoDigital na sua tela inicial ou na gaveta de aplicativos

## Passo 4: Acessando o Painel de Administração

Para acessar o painel de administração do ElMagoDigital:

1. Abra o aplicativo instalado

2. Toque no botão "Entrar" no canto superior direito

3. Use as seguintes credenciais:
   - Email: admin@elmagodigital.com
   - Senha: admin

4. Você será redirecionado automaticamente para o painel de administração

## Solução de Problemas Comuns

### O PWA Builder não reconhece meu site como uma PWA

- Verifique se todos os arquivos foram carregados corretamente no Netlify
- Certifique-se de que o manifest.json e service-worker.js estão na raiz do site
- Tente acessar diretamente o manifest.json (sua-url.netlify.app/manifest.json) para verificar se está acessível

### O APK não instala no meu dispositivo

- Verifique se você permitiu a instalação de aplicativos de fontes desconhecidas
- Alguns dispositivos podem ter restrições adicionais de segurança. Consulte as configurações específicas do seu dispositivo
- Tente baixar o APK diretamente no dispositivo e instalar a partir daí

### O aplicativo instalado não funciona corretamente

- Verifique se o site original no Netlify está funcionando corretamente
- Tente limpar o cache do aplicativo ou reinstalá-lo
- Verifique se seu dispositivo Android está atualizado

## Personalização Adicional do APK

Se você quiser personalizar ainda mais o APK antes de gerá-lo:

1. No PWA Builder, após selecionar Android, clique em "Options"
2. Aqui você pode personalizar:
   - Nome do pacote (com.seudominio.app)
   - Versão do aplicativo
   - Ícones personalizados (se os padrões não forem carregados corretamente)
   - Tela de splash
3. Depois de personalizar, clique em "Download" para gerar o APK personalizado

---

Parabéns! Agora você tem o ElMagoDigital como um aplicativo Android nativo que pode ser distribuído e instalado em qualquer dispositivo Android.
