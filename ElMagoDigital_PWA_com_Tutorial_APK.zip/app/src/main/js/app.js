// Configuração do Service Worker para PWA
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('Service Worker registrado com sucesso:', registration.scope);
            })
            .catch(error => {
                console.log('Falha ao registrar o Service Worker:', error);
            });
    });
}

// Configuração de partículas para o hero banner
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar partículas
    if (document.getElementById('particles-js')) {
        particlesJS('particles-js', {
            particles: {
                number: {
                    value: 80,
                    density: {
                        enable: true,
                        value_area: 800
                    }
                },
                color: {
                    value: "#00E5FF"
                },
                shape: {
                    type: "circle",
                    stroke: {
                        width: 0,
                        color: "#000000"
                    },
                },
                opacity: {
                    value: 0.5,
                    random: true,
                    anim: {
                        enable: true,
                        speed: 1,
                        opacity_min: 0.1,
                        sync: false
                    }
                },
                size: {
                    value: 3,
                    random: true,
                    anim: {
                        enable: true,
                        speed: 2,
                        size_min: 0.1,
                        sync: false
                    }
                },
                line_linked: {
                    enable: true,
                    distance: 150,
                    color: "#00E5FF",
                    opacity: 0.4,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 1,
                    direction: "none",
                    random: true,
                    straight: false,
                    out_mode: "out",
                    bounce: false,
                    attract: {
                        enable: true,
                        rotateX: 600,
                        rotateY: 1200
                    }
                }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: {
                        enable: true,
                        mode: "grab"
                    },
                    onclick: {
                        enable: true,
                        mode: "push"
                    },
                    resize: true
                },
                modes: {
                    grab: {
                        distance: 140,
                        line_linked: {
                            opacity: 1
                        }
                    },
                    push: {
                        particles_nb: 4
                    }
                }
            },
            retina_detect: true
        });
    }

    // Gerenciamento de páginas
    const pages = {
        home: document.querySelector('#app'),
        admin: document.querySelector('#adminPage'),
        courseDetail: document.querySelector('#courseDetailPage'),
        videoPlayer: document.querySelector('#videoPlayerPage')
    };

    // Estado da aplicação
    const appState = {
        currentPage: 'home',
        isLoggedIn: false,
        isAdmin: false,
        currentCourse: null,
        currentVideo: null,
        courses: [
            {
                id: 1,
                title: 'Desenvolvimento Web',
                description: 'Aprenda a criar sites e aplicações web modernas com HTML, CSS e JavaScript.',
                instructor: 'João Silva',
                rating: 4.8,
                students: 42,
                image: '',
                status: 'active'
            },
            {
                id: 2,
                title: 'Marketing Digital',
                description: 'Domine as estratégias de marketing digital para promover produtos e serviços online.',
                instructor: 'Maria Santos',
                rating: 4.6,
                students: 38,
                image: '',
                status: 'active'
            },
            {
                id: 3,
                title: 'Design Gráfico',
                description: 'Aprenda os fundamentos do design gráfico e crie peças visuais impactantes.',
                instructor: 'Pedro Oliveira',
                rating: 4.9,
                students: 56,
                image: '',
                status: 'active'
            }
        ]
    };

    // Navegação
    function navigateTo(page) {
        // Ocultar todas as páginas
        Object.values(pages).forEach(p => {
            if (p) p.style.display = 'none';
        });

        // Mostrar a página selecionada
        if (pages[page]) {
            pages[page].style.display = 'block';
            appState.currentPage = page;
            
            // Atualizar navegação inferior
            updateBottomNav();
        }
    }

    // Atualizar navegação inferior
    function updateBottomNav() {
        const navItems = document.querySelectorAll('.bottom-nav-item');
        navItems.forEach(item => {
            item.classList.remove('active');
            if (item.dataset.page === appState.currentPage) {
                item.classList.add('active');
            }
        });
    }

    // Configurar eventos de navegação
    const navItems = document.querySelectorAll('.bottom-nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.dataset.page;
            
            if (page === 'profile' && !appState.isLoggedIn) {
                showModal('loginModal');
            } else {
                navigateTo(page);
            }
        });
    });

    // Manipulação de carrosséis
    const carousels = document.querySelectorAll('.carousel');
    carousels.forEach(carousel => {
        const container = carousel.querySelector('.carousel-container');
        const prevBtn = carousel.querySelector('.carousel-control.prev');
        const nextBtn = carousel.querySelector('.carousel-control.next');
        
        if (prevBtn && nextBtn && container) {
            // Botão anterior
            prevBtn.addEventListener('click', () => {
                container.scrollBy({
                    left: -container.offsetWidth / 2,
                    behavior: 'smooth'
                });
            });
            
            // Botão próximo
            nextBtn.addEventListener('click', () => {
                container.scrollBy({
                    left: container.offsetWidth / 2,
                    behavior: 'smooth'
                });
            });
            
            // Arrastar para scroll (touch e mouse)
            let isDown = false;
            let startX;
            let scrollLeft;

            container.addEventListener('mousedown', (e) => {
                isDown = true;
                startX = e.pageX - container.offsetLeft;
                scrollLeft = container.scrollLeft;
            });

            container.addEventListener('mouseleave', () => {
                isDown = false;
            });

            container.addEventListener('mouseup', () => {
                isDown = false;
            });

            container.addEventListener('mousemove', (e) => {
                if (!isDown) return;
                e.preventDefault();
                const x = e.pageX - container.offsetLeft;
                const walk = (x - startX) * 2;
                container.scrollLeft = scrollLeft - walk;
            });

            // Touch events
            container.addEventListener('touchstart', (e) => {
                isDown = true;
                startX = e.touches[0].pageX - container.offsetLeft;
                scrollLeft = container.scrollLeft;
            });

            container.addEventListener('touchend', () => {
                isDown = false;
            });

            container.addEventListener('touchmove', (e) => {
                if (!isDown) return;
                const x = e.touches[0].pageX - container.offsetLeft;
                const walk = (x - startX) * 2;
                container.scrollLeft = scrollLeft - walk;
            });
        }
    });

    // Manipulação de modais
    function showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'flex';
        }
    }

    function hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'none';
        }
    }

    // Configurar botões de fechar modal
    const closeButtons = document.querySelectorAll('.modal-close');
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal) {
                modal.style.display = 'none';
            }
        });
    });

    // Fechar modal ao clicar fora
    window.addEventListener('click', function(e) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    });

    // Botão de login
    const loginBtn = document.querySelector('.btn-login');
    if (loginBtn) {
        loginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showModal('loginModal');
        });
    }

    // Alternar entre login e registro
    const showRegisterBtn = document.getElementById('showRegister');
    if (showRegisterBtn) {
        showRegisterBtn.addEventListener('click', function(e) {
            e.preventDefault();
            hideModal('loginModal');
            showModal('registerModal');
        });
    }

    const showLoginBtn = document.getElementById('showLogin');
    if (showLoginBtn) {
        showLoginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            hideModal('registerModal');
            showModal('loginModal');
        });
    }

    // Processamento de formulários
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            // Simulação de login
            if (email && password) {
                // Verificar se é admin (para demonstração)
                if (email === 'admin@elmagodigital.com' && password === 'admin') {
                    appState.isAdmin = true;
                    appState.isLoggedIn = true;
                    hideModal('loginModal');
                    navigateTo('admin');
                    showToast('Login de administrador realizado com sucesso!');
                } else {
                    appState.isLoggedIn = true;
                    appState.isAdmin = false;
                    hideModal('loginModal');
                    showToast('Login realizado com sucesso!');
                }
            }
        });
    }

    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('regName').value;
            const email = document.getElementById('regEmail').value;
            const password = document.getElementById('regPassword').value;
            
            // Simulação de registro
            if (name && email && password) {
                appState.isLoggedIn = true;
                hideModal('registerModal');
                showToast('Registro realizado com sucesso!');
            }
        });
    }

    // Administração de cursos
    const addCourseBtn = document.getElementById('addCourseBtn');
    if (addCourseBtn) {
        addCourseBtn.addEventListener('click', function() {
            showModal('addCourseModal');
        });
    }

    const addCourseForm = document.getElementById('addCourseForm');
    if (addCourseForm) {
        addCourseForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const title = document.getElementById('courseTitle').value;
            const description = document.getElementById('courseDescription').value;
            const category = document.getElementById('courseCategory').value;
            
            // Adicionar novo curso
            if (title && description && category) {
                const newCourse = {
                    id: appState.courses.length + 1,
                    title: title,
                    description: description,
                    category: category,
                    instructor: 'Novo Instrutor',
                    rating: 0,
                    students: 0,
                    image: '',
                    status: 'active'
                };
                
                appState.courses.push(newCourse);
                hideModal('addCourseModal');
                showToast('Curso adicionado com sucesso!');
                
                // Limpar formulário
                addCourseForm.reset();
            }
        });
    }

    // Manipulação de módulos do curso
    const moduleHeaders = document.querySelectorAll('.module-header');
    moduleHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const moduleItem = this.closest('.module-item');
            const moduleLessons = moduleItem.querySelector('.module-lessons');
            const moduleToggle = this.querySelector('.module-toggle');
            
            if (moduleLessons.style.display === 'none') {
                moduleLessons.style.display = 'block';
                moduleToggle.textContent = '▼';
            } else {
                moduleLessons.style.display = 'none';
                moduleToggle.textContent = '▶';
            }
        });
    });

    // Reprodução de vídeo
    const lessonItems = document.querySelectorAll('.lesson-item');
    lessonItems.forEach(item => {
        item.addEventListener('click', function() {
            const videoSrc = this.dataset.video;
            const videoTitle = this.querySelector('.lesson-title').textContent;
            
            // Configurar player de vídeo
            const videoPlayer = document.getElementById('videoPlayer');
            if (videoPlayer) {
                const source = videoPlayer.querySelector('source');
                if (source) {
                    source.src = videoSrc || '';
                    videoPlayer.load();
                }
                
                // Atualizar informações do vídeo
                const videoTitleElement = document.querySelector('.video-title');
                if (videoTitleElement) {
                    videoTitleElement.textContent = videoTitle;
                }
                
                // Navegar para a página do player
                navigateTo('videoPlayer');
            }
        });
    });

    // Controles de vídeo personalizados
    const videoPlayer = document.getElementById('videoPlayer');
    const playPauseBtn = document.querySelector('.play-pause');
    const progressBar = document.querySelector('.progress-fill');
    const videoTime = document.querySelector('.video-time');
    const fullscreenBtn = document.querySelector('.fullscreen');
    
    if (videoPlayer && playPauseBtn && progressBar && videoTime) {
        // Play/Pause
        playPauseBtn.addEventListener('click', function() {
            if (videoPlayer.paused) {
                videoPlayer.play();
                this.querySelector('.control-icon').textContent = '⏸';
            } else {
                videoPlayer.pause();
                this.querySelector('.control-icon').textContent = '▶';
            }
        });
        
        // Atualizar barra de progresso
        videoPlayer.addEventListener('timeupdate', function() {
            const progress = (videoPlayer.currentTime / videoPlayer.duration) * 100;
            progressBar.style.width = progress + '%';
            
            // Atualizar tempo
            const currentMinutes = Math.floor(videoPlayer.currentTime / 60);
            const currentSeconds = Math.floor(videoPlayer.currentTime % 60);
            const durationMinutes = Math.floor(videoPlayer.duration / 60) || 0;
            const durationSeconds = Math.floor(videoPlayer.duration % 60) || 0;
            
            videoTime.textContent = `${currentMinutes.toString().padStart(2, '0')}:${currentSeconds.toString().padStart(2, '0')} / ${durationMinutes.toString().padStart(2, '0')}:${durationSeconds.toString().padStart(2, '0')}`;
        });
        
        // Clicar na barra de progresso
        const progressBarContainer = document.querySelector('.progress-bar');
        if (progressBarContainer) {
            progressBarContainer.addEventListener('click', function(e) {
                const rect = this.getBoundingClientRect();
                const pos = (e.clientX - rect.left) / rect.width;
                videoPlayer.currentTime = pos * videoPlayer.duration;
            });
        }
        
        // Tela cheia
        if (fullscreenBtn) {
            fullscreenBtn.addEventListener('click', function() {
                if (videoPlayer.requestFullscreen) {
                    videoPlayer.requestFullscreen();
                } else if (videoPlayer.webkitRequestFullscreen) {
                    videoPlayer.webkitRequestFullscreen();
                } else if (videoPlayer.msRequestFullscreen) {
                    videoPlayer.msRequestFullscreen();
                }
            });
        }
    }

    // Botões de explorar e saiba mais
    const exploreBtn = document.querySelector('.btn-primary');
    if (exploreBtn) {
        exploreBtn.addEventListener('click', function() {
            const coursesSection = document.querySelector('.carousel-section');
            if (coursesSection) {
                coursesSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }

    // Toast notifications
    function showToast(message, duration = 3000) {
        const toast = document.getElementById('toast');
        if (toast) {
            toast.textContent = message;
            toast.style.display = 'block';
            
            setTimeout(() => {
                toast.style.display = 'none';
            }, duration);
        }
    }

    // Verificar conexão
    function updateOnlineStatus() {
        const condition = navigator.onLine ? "online" : "offline";
        const offlineIndicator = document.querySelector('.offline-indicator');
        
        if (condition === "offline") {
            if (offlineIndicator) {
                offlineIndicator.style.display = 'block';
            }
        } else {
            if (offlineIndicator) {
                offlineIndicator.style.display = 'none';
            }
        }
    }

    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
    updateOnlineStatus();

    // Inicializar a aplicação
    function initApp() {
        // Verificar se há usuário logado (simulação)
        if (localStorage.getItem('isLoggedIn') === 'true') {
            appState.isLoggedIn = true;
            if (localStorage.getItem('isAdmin') === 'true') {
                appState.isAdmin = true;
                navigateTo('admin');
            }
        }
        
        // Mostrar spinner de carregamento
        const loadingSpinner = document.getElementById('loadingSpinner');
        if (loadingSpinner) {
            loadingSpinner.style.display = 'flex';
            
            // Simular carregamento
            setTimeout(() => {
                loadingSpinner.style.display = 'none';
            }, 1500);
        }
    }

    // Iniciar aplicação
    initApp();
});
